function [L,w]=laplacianMatrix1(Hsi,param)
%Build graph
param.include4N=0;
if param.nbNeight>0
    w=Dgraph1(Hsi, param);
else
    w=speye(size(Hsi,1)*size(Hsi,2));
end
w=max(w,w');
w=sparse(bsxfun(@times,sum(w,2).^(-0.5),w));
w=sparse(bsxfun(@times,w,sum(w,2)'.^(-0.5)));
L=diag(sum(w,2)+sum(w,1)')-2*w;
end