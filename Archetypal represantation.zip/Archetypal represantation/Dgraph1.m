function w=Dgraph1(image, param)
% if size(image,3)>20
% image=PCA_Hsi(image,50,1);
% end
t=tic;
verb = 0;
windowing = 1;
NIds_read = 0;
[Ny,Nx,L] = size(image);
szW = param.szW; % the window will ne of size 2*szW+1 
nbNeight = param.nbNeight;
% if nargin<5
%     graphfile = 'temp';
% end;
% file = ['graph_data/' graphfile '.mat'];

% if windowing
%     %%%%%%%% read neighbours from previous iteration and update value on w, but not the neighbours 
%     if( exist(['graph_data/' graphfile '.mat'])==2 )
%         disp('read previous NIds');
%         load(file,'NIds');
%     end;
%     if( exist(['graph_data/NIds_' int2str(Ny) '_' int2str(Nx) '_' int2str(szW)])==2 )
%         load(['graph_data/NIds_' int2str(Ny) '_' int2str(Nx) '_' int2str(szW)]);
%         NIds_read = 1;
%     end;
% end;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% collect patches
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if verb
    disp('collecting patches ...');
    tic
end;

% patch size = 2m+1 x 2m+1
m = 0; 
%m = 2; 
s = 2*m+1;

% extend image to deal with boundaries
u = image;
uext = zeros(Ny+2*m,Nx+2*m,L);
uext(m+1:m+Ny,m+1:m+Nx,:) = u;
uext(1:m,:,:) = uext(m+m:-1:m+1,:,:);
uext(m+Ny+1:m+Ny+m,:,:) = uext(m+Ny:-1:m+Ny+1-m,:,:);
uext(:,1:m,:) = uext(:,m+m:-1:m+1,:);
uext(:,m+Nx+1:m+Nx+m,:) = uext(:,m+Nx:-1:m+Nx+1-m,:);

    Tp_ids = zeros(Ny,Nx,s^2);
    % first m rows, the window goes from row 1:m
    [X,Y] = meshgrid(1:s,1:s);
    window = sub2ind([Ny+2*m Nx+2*m],X(:),Y(:));
    window = reshape(window,1,s^2);
    for x=1:Nx
        for y=1:Ny
            Tp_ids(y,x,:) = window + y - 1;
        end     
        window = window + Ny + 2*m;
    end
    Tp_ids = reshape(Tp_ids,Ny*Nx,s^2); 
    clear window

Tp = zeros(Ny*Nx,L*s^2);
for l=1:L
    ul = reshape(uext(:,:,l),Ny+2*m,Nx+2*m);
    Tp(:,(l-1)*(s^2) + (1:s^2)) = reshape(ul(Tp_ids(:)),Nx*Ny,s^2);
end;

% rearrange the order of neighborhood pixels
% centerIds=(s^2+1)/2;
% for i=1:size(Tp,1)
%     tempPatch=Tp(i,:);
%     tempPatch=reshape(tempPatch,s^2,L);
%     NNDist=sum((ones(s^2,1)*tempPatch(centerIds,:)-tempPatch).^2,2);
%     [~,ids]=sort(NNDist);
%     tempPatch=tempPatch(ids,:);
%     Tp(i,:)=tempPatch(:)';
% end

if not(NIds_read)    
    wside = 2*szW+1;
    NIds = zeros(Ny,Nx,wside^2);
    % first szW rows, the window goes from row 1:wside
    [X,Y] = meshgrid(1:wside,1:wside);
    window = sub2ind([Ny Nx],X(:),Y(:));
    window = reshape(window,wside^2,1);
    for x=1:(szW+1)
        for y=1:(szW+1)      
            NIds(y,x,:) = window;
        end
        for y=(szW+2):(Ny-szW-1)
            NIds(y,x,:) = window + y - (szW+1);
        end
        for y=(Ny-szW):Ny
            NIds(y,x,:) = window + Ny - wside;
        end        
    end
    % middle rows, window centered at pixel with szW rows up nad szW rows down
    for x=(szW+2):(Nx-szW)
        window = window + Ny;
        for y=1:(szW+1)     
            NIds(y,x,:) = window;
        end
        for y=(szW+2):(Ny-szW-1)
            NIds(y,x,:) = window + y - (szW+1);
        end
        for y=(Ny-szW):Ny
            NIds(y,x,:) = window + Ny - wside;
        end        
    end  
    % last szW rows, the window goes from row (Nx-wside):Nx
    for x=(Nx-szW+1):Nx
        for y=1:(szW+1)  
            NIds(y,x,:) = window;
        end
        for y=(szW+2):(Ny-szW-1)
            NIds(y,x,:) = window + y - (szW+1);
        end
        for y=(Ny-szW):Ny
            NIds(y,x,:) = window + Ny - wside;
        end        
    end    
    NIds = reshape(NIds,Ny*Nx,wside^2);
end;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% compute weight graph
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if verb
    toc
    disp('computing the weight on the graph ...');
end;

opts.kNN=nbNeight; % opts.kNN is the number of neighbors
opts.alpha=1; % opts.alpha is a universal scaling factor
opts.include4neighbors=0;
opts.imgSize=[Ny,Nx];
opts.quiet = 1;
% opts.kNNdelta specifies which nearest 
% neighbor determines the local scale
if windowing
    [w NIds NNDist] = fgf1(Tp,opts,NIds);
else
    w = fgf1(Tp,opts);
end;