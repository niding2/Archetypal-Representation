function [coefMap0,objLaft]=randomWalker1(Hsi0,coefMap0,param)
%Solve the random-waker like regularization problem
[M0,N0,C0]=size(coefMap0);
step=150;
nr=ceil(M0/step);
nc=ceil(N0/step);
pad=param.szW*2;
objLaft=0;
% To avoid theout of memory problem when the input image is too large, we split 
% the image into regular patches with reasonable size and process then sequentially. 
for i=1:nr
    for j=1:nc
        rangeRow0=((i-1)*step+1):min(i*step,M0);
        rangeRow=max((i-1)*step+1-pad,1):min(i*step+pad,M0);
        rangeCol0=((j-1)*step+1):min(j*step,N0);
        rangeCol=max((j-1)*step+1-pad,1):min(j*step+pad,N0);
        Hsi=Hsi0(rangeRow,rangeCol,:);
        coefMap=coefMap0(rangeRow,rangeCol,:);
        [M,N,C]=size(coefMap);
        %construc the Laplacian matrix
        L=laplacianMatrix1(Hsi,param);
        coefMap=reshape(coefMap,[M*N,C]);
        %Solve linear system
        coefMap=(param.gamma*(L+L')/2+param.beta*speye(size(coefMap,1)))\(param.beta*coefMap);
        objLaft=objLaft+0.5*param.gamma*trace(coefMap'*L*coefMap);
        coefMap=reshape(coefMap,[M,N,C]);
        Rstart=(rangeRow0(1)-rangeRow(1)+1);
        Rend=(rangeRow0(1)-rangeRow(1)+length(rangeRow0));
        Cstart=(rangeCol0(1)-rangeCol(1)+1);
        Cend=(rangeCol0(1)-rangeCol(1)+length(rangeCol0));
        coefMap=coefMap(Rstart:Rend,Cstart:Cend,:);
        coefMap0(rangeRow0,rangeCol0,:)=coefMap;
    end
end

