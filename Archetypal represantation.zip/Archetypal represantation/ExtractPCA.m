%extract spacial features :mean and devariate
function Hsi=ExtractPCA(Hsi,percent,k0)
M=size(Hsi,1);
N=size(Hsi,2);
Hsi=reshape(Hsi,[M*N,size(Hsi,3)]);
Hsi=bsxfun(@minus,Hsi,mean(Hsi,1));
corMatrix=Hsi'*Hsi;

% k=param.k;
[V,D]=eig(corMatrix);
D=diag(D);
[D,ind]=sort(abs(D),'descend');

if exist('k0','var')
    k=k0;
else
    sumD=0;
    totalD=sum(abs(D));
    for i=1:length(D)
        sumD=sumD+D(i);
        if (sumD/totalD)>percent
            k=i;
            break;
        end
    end
end
% k=5;
V=V(:,ind(1:k));
Hsi=Hsi*V;
Hsi=reshape(Hsi,[M,N,size(Hsi,2)]);