function [Labelmap,et,optObj]=Archetypal_Approximate_Graph_Laplacian_SVD(Hsi,trainRow_Col,trainLabel,testmap,param)
t=tic;
[M,N]=size(testmap);
param.trainLabel=trainLabel;
param.trainRow_Col=trainRow_Col;
numTrain=length(trainLabel);
HsiPCA=ExtractPCA(Hsi,0.98);% use the PCA to reduce the dimensions when finding the kNN.
D=[];
for i=1:numTrain
    r=trainRow_Col(i,1);
    c=trainRow_Col(i,2);
    HH=Hsi(r,c,:);
    D(:,end+1)=HH(:);
end
Hsi=reshape(Hsi,[size(Hsi,1)*size(Hsi,2),size(Hsi,3)])';
scale=100;% multiply a constant to avoid the precision problem, since it is in float precision in the c++ implementation of mexDecompSimplex;
AF0=full(mexDecompSimplex(Hsi*scale,D*scale, param));
AF0=reshape(AF0',[M,N,size(AF0,1)]);
param.epsion=0.1;
S=eig(D'*D);
S=sort(S,'descend');
opt_Obj=Inf;index=1;Objs=[];
% % find the searching range in terms of the singular value of DtD;
for i=1:length(S)
    param.beta=S(i); 
    [AF1,obj_aft_Lap]=randomWalker1(HsiPCA,AF0,param); 
    AF1=reshape(AF1,[M*N,size(AF1,3)])';
    obj_aft_SR=sum(sum((Hsi-D*AF1).^2));
    obj=obj_aft_SR+obj_aft_Lap;
    Objs(end+1)=obj;
    if obj<=opt_Obj
       opt_Obj=obj;
       optAF=AF1;
       optObj=[obj_aft_SR,obj_aft_Lap];
    elseif obj>opt_Obj
        index=i;
        break;
    end
end
% %  conduct the quadratic interpolation based line-search;
x1=S(index);x2=S(index-1);x3=S(index-2);
f1=Objs(end);f2=Objs(end-1);f3=Objs(end-2);
x_min_pre=x2;
x_min_cur=x2+param.epsion;
while abs(x_min_cur-x_min_pre)>=param.epsion
    x_min_pre=x2;
    c1 = (f3 - f1) / (x3 - x1);  
    c2 = ((f2 - f1) / (x2 - x1) - c1) / (x2 - x3);  
    x_min = 0.5 * (x1 + x3 - c1 / c2);  
    param.beta=x_min; 
    [AF1,obj_aft_Lap]=randomWalker1(HsiPCA,AF0,param);
    AF1=reshape(AF1,[M*N,size(AF1,3)])';
    obj_aft_SR=sum(sum((Hsi-D*AF1).^2));
    obj=obj_aft_SR+obj_aft_Lap;
    if x_min<=x2
        if obj>f2
            x1=x_min;
            f1=obj;
        else
            x3=x2;
            f3=f2;
            x2=x_min;
            f2=obj;
            optAF=AF1;
            optObj=[obj_aft_SR,obj_aft_Lap];
        end
    else 
        if obj>f2
            x3=x_min;
            f3=obj;
        else
            x1=x2;
            f1=f2;
            x2=x_min;
            f2=obj;
            optAF=AF1;
            optObj=[obj_aft_SR,obj_aft_Lap];
        end
    end
    [x1,x2,x3];
    x_min_cur=x2;
end
%classification using linear-SVM
AF=reshape(optAF',[M,N,size(AF1,1)]);
Labelmap=classifySVM(trainRow_Col,trainLabel,AF);
toc(t)
et=toc(t);
end

function Labelmap=classifySVM(trainRow_Col,trainLabel,AFm)
XTrain=[];
for i=1:size(trainRow_Col,1)
    HH=AFm(trainRow_Col(i,1),trainRow_Col(i,2),:);
    XTrain(:,end+1)=HH(:);
end
% % SVM training
c=10^2;
model = svmtrain(trainLabel ,XTrain',['-s 0 -t 0 -h 0 -q -c ',num2str(c)]);

% % SVM testing
step=1000;
[M,N,K]=size(AFm);
AFm=reshape(AFm,[M*N,K]);
nStep=ceil(M*N/step);
Labelmap=zeros(M*N,1); 
for i=1:nStep
    index=(i-1)*step+1:min(i*step,M*N);
    tmpAFm=AFm(index,:);
    predict_label_L  = svmpredict(ones(size(tmpAFm,1),1), tmpAFm, model, '-q');
    Labelmap(index)= model.Label(predict_label_L(:));
end
Labelmap=reshape(Labelmap,[M,N]);
end
