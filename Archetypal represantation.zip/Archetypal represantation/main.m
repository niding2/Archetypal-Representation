clc;
clear all;
warning off;
addpath(genpath(pwd));
S=load('Indian_pines_corrected.mat');
Hsi=double(S.indian_pines_corrected);
S=load('Indian_pines_gr.mat');
GroundTure=S.Indian_pines_gr;
Dataset='Indian';
Class=1:16; 
percent=[30];% number of training samples per calss.
Hsi= Hsi./repmat(sqrt(sum((Hsi.^2),3))+eps,[1,1,size(Hsi,3)]);%normalize the spectral signature

% % randomly sampled training samples
trainLabel=[];trainRow_Col=[];
testmap=GroundTure;
for i=1:length(Class)
    [row,col]=find(GroundTure==Class(i));
    select=randperm(size(row,1));
    if percent>1
       numTrainclass(i)=min(percent,ceil(0.1*length(select)));
    else
       numTrainclass(i)=max(ceil(percent*length(select)),3);
    end
    for j=1:numTrainclass(i)
        testmap(row(select(j)),col((select(j))))=0;
    end
    trainRow_Col=[trainRow_Col;[row(select(1:numTrainclass(i))),col(select(1:numTrainclass(i)))]];
    trainLabel=[trainLabel;ones(numTrainclass(i),1)*i];
end
Labelmap=[];OA=[];

% parameter setups
param.szW=3; % neighborhood window width for kNN 
param.nbNeight=7; % number of neighbors: k 
param.gamma=1; % regularization parameter

% % exact optimization
param.maxIter=15; % maximum interation steps in exact optimization
[Labelmap1,et1]=Archetypal_Graph_Laplacian(Hsi,trainRow_Col,trainLabel,testmap,param);
Labelmap(:,:,end+1)=Labelmap1(:,:,end);
result1=checkCorrect(Class,testmap,Labelmap1(:,:,end));
OA(end+1)=result1.acc

% % approximate optimization
[Labelmap2,et2]=Archetypal_Approximate_Graph_Laplacian_SVD(Hsi,trainRow_Col,trainLabel,testmap,param);
Labelmap(:,:,end+1)=Labelmap2(:,:,end);
result2=checkCorrect(Class,testmap,Labelmap2(:,:,end));
OA(end+1)=result2.acc
for f=2:size(Labelmap,3)
    figure;
    imshow(label2rgb(Labelmap(:,:,f)));
end