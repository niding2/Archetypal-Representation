function result=checkCorrect(C,GroundTure,Labelmap)
BackLabel=100*ones(size(Labelmap));
for a=1:size(Labelmap,1)
    for b=1:size(Labelmap,2)
        if Labelmap(a,b)>0
        BackLabel(a,b)=C(Labelmap(a,b));
%         BackLabel(a,b)=Labelmap(a,b);
        end
    end
end
    % confusion matrix
    confMat = zeros(length(C), length(C));
    for k = 1 : length(C)     % estimated 
        A1=(BackLabel==C(k));
        for j = 1 : length(C)     % true
            A2=(GroundTure==C(j));
            AA=A1.*A2;
            confMat(k, j) =sum(AA(:)) ;
        end
    end

%     perc = [(sum(confMat, 2) - diag(confMat)) ./ sum(confMat, 2), ...
%             (sum(confMat)' - diag(confMat)) ./ sum(confMat)', ...
%             diag(confMat) ./ sum(confMat)',...
%             diag(confMat) ./ sum(confMat, 2)];
    perc = diag(confMat) ./ sum(confMat)';
    p0 = sum(diag(confMat)) / sum(confMat(:));
    pc = sum(sum(confMat)' .* sum(confMat, 2)) / sum(confMat(:))^2;

    acc = sum(diag(confMat)) / sum(confMat(:));
    kappa = (p0 - pc) / (1 - pc);
    
    %% store results
    result.confMat = confMat;
    result.perc = perc*100;
    result.AA = mean(perc)*100;
    result.acc = acc * 100;
    result.kappa = kappa;
    result.testAcc = sum(diag(confMat));
    result.Ntest = sum(confMat(:));
    