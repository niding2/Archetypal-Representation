function [w NNIdxs NNDist]=fgf1(A,opts,NNIdxs)

%w=fgf(A,opts,NNIdxs)
%implementation of self-tuning 
%weight matrix construction, as in Perona and Zelnik-Manor 2004
%using the tstools nearest neighbor searcher
%opts.kNN is the number of neighbors
%opts.alpha is a universal scaling factor
%opts.kNNdelta specifies which nearest neighbor determines the local scale
%w is forced to be symmetric by averaging with its adjoint.
%if NNIdxs is specified, uses these instead of nnn-search.
%NNIdxs should be N x opts.kNN




[N dim]=size(A);

if isfield(opts,'quiet')
    if opts.quiet==1
        quiet=1;
    else
        quiet=0;
    end
else
    quiet=0;
end

if isfield(opts,'single');
    singlesingle=1;
else
    singlesingle=0;
end

thresh=0;
if isfield(opts,'thresh')
    thresh=1;
end


if isfield(opts,'NNcoordinates')
    if length(opts.NNcoordinates)>0
        NNcoordinates=opts.NNcoordinates;
        coarse=1;
    else
        coarse=0;
        NNcoordinates=[1:dim];
    end
else
    coarse=0;
    NNcoordinates=[1:dim];
end


if nargin==2
    atria=nn_prepare(A(:,NNcoordinates));
    NNIdxs=zeros(N,opts.kNN); 
    NNDist=zeros(N,opts.kNN);
    ccount=1;
    [NNIdxs NNDist]=nn_search(A(:,NNcoordinates),atria,A(:,NNcoordinates),opts.kNN);

    if coarse==1
        for k=1:N
            for j=1:opts.kNN
                NNDist(k,j)=norm(A(k,:)-A(NNIdxs(k,j),:));
            end
        end
    end
    
else

    sws=size(NNIdxs,2);%search window size
    NNDist=zeros(N,sws);
    for k=1:N
%         for j=1:sws
%             NNDist(k,j)=norm(A(k,:)-A(NNIdxs(k,j),:));
%         end
        NNDist(k,:)=sqrt(sum((ones(sws,1)*A(k,:)-A(NNIdxs(k,:),:)).^2,2));
    end
    
   % include the 4/8 nearest neighbors
   if isfield(opts,'include4neighbors') && opts.include4neighbors==1
%         neigh4Ids = [(sws+1)/2-sqrt(sws),(sws+1)/2-1,(sws+1)/2+1,(sws+1)/2+sqrt(sws)];
          NNIdxs4n=zeros(N,4);
          NNDist4n=zeros(N,4);
        for i=1:N
            [r,c]=ind2sub(opts.imgSize,NNIdxs(i,:));
            [rc,cc]=ind2sub(opts.imgSize,i);
            RC=[r(:),c(:)];RCc=[rc,cc];
            Dist=sum((RC-ones(sws,1)*RCc).^2,2);
            [~ ,Ids]=sort(Dist);
            % 4 nearest neighbors
            neigh4Ids=Ids(2:5);
            NNIdxs4n(i,:) = NNIdxs(i,neigh4Ids);
            NNDist4n(i,:) = NNDist(i,neigh4Ids);
            NNIdxs(i,1:sws-4) = NNIdxs(i,setdiff(1:sws,neigh4Ids));
            NNDist(i,1:sws-4) = NNDist(i,setdiff(1:sws,neigh4Ids));    
        end
            NNIdxs=NNIdxs(:,1:sws-4);
            NNDist=NNDist(:,1:sws-4);
   end
   
%     NNDist4n=zeros(N,4);
%     for i=1:N
%         [r,c]=ind2sub(opts.imgSize,NNIdxs(i,:));
%         [rc,cc]=ind2sub(opts.imgSize,i);
%         RC=[r(:),c(:)];RCc=[rc,cc];
%         Dist=sum((RC-ones(sws,1)*RCc).^2,2);
%         [~ ,Ids]=sort(Dist);
%         % 4 nearest neighbors
%         neigh4Ids=Ids(2:5);
%         NNDist4n(i,:) = NNDist(i,neigh4Ids);
%     end
        
     sws=size(NNIdxs,2);%search window size
     opts.kNN=min(opts.kNN,sws-1);
    if opts.kNN<sws
        
        [ju juu]=sort(NNDist,2);
        for s=1:N
            NNDist(s,1:opts.kNN)=NNDist(s,juu(s,2:opts.kNN+1));
            NNIdxs(s,1:opts.kNN)=NNIdxs(s,juu(s,2:opts.kNN+1));
        end
        NNDist=NNDist(:,1:opts.kNN);
        NNIdxs=NNIdxs(:,1:opts.kNN);
    end
    
    if isfield(opts,'include4neighbors') && opts.include4neighbors==1
        NNIdxs = [NNIdxs4n, NNIdxs];
        NNDist = [NNDist4n, NNDist];
        [ju juu]=sort(NNDist,2);
        for s=1:N
            NNDist(s,:)=NNDist(s,juu(s,:));
            NNIdxs(s,:)=NNIdxs(s,juu(s,:));
        end
    end
    
end

sigma=sqrt(mean(NNDist.^2,2)');
opts.kNN=size(NNIdxs,2);
idx=1;idxi=[];idxj=[]; entries=zeros(1,opts.kNN*N); idxi(opts.kNN*N) = int16(0);idxj(opts.kNN*N) = int16(0);
for lk = 1:N
    idxi(idx:idx+opts.kNN-1)=lk;
    idxj(idx:idx+opts.kNN-1)=NNIdxs(lk,:);
    entries(idx:idx+opts.kNN-1)=max(exp(-(NNDist(lk,:).^2)./(opts.alpha*sigma(lk)*sigma(NNIdxs(lk,:))+eps)),1e-6);
%     entries(idx:idx+opts.kNN-1)= entries(idx:idx+opts.kNN-1)/sum(entries(idx:idx+opts.kNN-1)); % normalize
    idx=idx+opts.kNN;
end;
if thresh
    id=find(abs(entries)<opts.thresh);
    entries(id)=0;
end

w=sparse(idxi,idxj,entries,N,N);
if singlesingle==1
    w=single(w);
end


