function [Labelmap,et,A]=Archetypal_Graph_Laplacian(Hsi,trainRow_Col,trainLabel,testmap,param)
[M,N]=size(testmap);
HsiPCA=ExtractPCA(Hsi,0.98);
D=[];
for i=1:size(trainRow_Col,1)
    r=trainRow_Col(i,1);
    c=trainRow_Col(i,2);
    HH=Hsi(r,c,:);
    D(:,end+1)=HH(:);
end
L=laplacianMatrix1(HsiPCA,param);
w=-(L+L')/2;
sum_w=-diag(w);
w=w+diag(sum_w);
Hsi=reshape(Hsi,[size(Hsi,1)*size(Hsi,2),size(Hsi,3)])';
A=zeros(size(D,2),size(Hsi,2));
OA=[];Obj=[];Time=[];
Ie=eye(size(D,2));
scale=100;
Dscale=D*scale;
DtDscale=Dscale'*Dscale;
DtAscale=Dscale'*(Hsi*scale);
for iter=1:param.maxIter+1
    t=tic;
    if iter==1
       A=full(mexDecompSimplex(DtAscale,[], DtDscale, param));
    else
        for i=1:M*N
            index=w(:,i)>0;
            Am=A(:,index)*(w(index,i)*param.gamma/2);
            sumDiag=param.gamma/2*sum_w(i);
            tmpDtD=(DtDscale+sumDiag*scale^2*Ie);
            tmpDtA=(DtAscale(:,i)+Am*scale^2);
            param.warm=true;param.alphaCurr=A(:,i);
            A(:,i)=mexDecompSimplex(tmpDtA, [], tmpDtD, param);
        end
    end
    Time(end+1)=toc(t)
    Labelmap=classifySVM(trainRow_Col,trainLabel,reshape(A',[M,N,size(A,1)]));
    result=checkCorrect(unique(trainLabel),testmap-min(testmap(:)),Labelmap);
    OA(end+1,:)=[result.acc]
    objSR=sum(sum((Hsi-D*A).^2));
    objLap=0.5*param.gamma*(trace(A*L*A'));
    Obj(end+1,:)=[objSR,objLap,objSR+objLap]
end
et=toc(t);
end

% classify the iamge using linear-SVM
function Labelmap=classifySVM(trainRow_Col,trainLabel,AFm)
XTrain=[];
for i=1:size(trainRow_Col,1)
    HH=AFm(trainRow_Col(i,1),trainRow_Col(i,2),:);
    XTrain(:,end+1)=HH(:);
end
c=10^2;
model = svmtrain(trainLabel ,XTrain',['-s 0 -t 0 -h 0 -q -c ',num2str(c)]);
XTrain0=XTrain(:,model.sv_indices);
if isempty(XTrain0)
    sum(sum(isNaN(XTrain)))
    max(XTrain(:))
end
step=1000;
[M,N,K]=size(AFm);
AFm=reshape(AFm,[M*N,K]);
nStep=ceil(M*N/step);
Labelmap=zeros(M*N,1); 
for i=1:nStep
    index=(i-1)*step+1:min(i*step,M*N);
    tmpAFm=AFm(index,:);
    predict_label_L  = svmpredict(ones(size(tmpAFm,1),1), tmpAFm, model, '-q');
    Labelmap(index)= model.Label(predict_label_L(:));
end
Labelmap=reshape(Labelmap,[M,N]);
end